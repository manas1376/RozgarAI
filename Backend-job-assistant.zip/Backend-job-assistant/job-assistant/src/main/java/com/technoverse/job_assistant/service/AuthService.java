package com.technoverse.job_assistant.service;

import com.technoverse.job_assistant.model.AuthUser;
import com.technoverse.job_assistant.model.UserProfile;
import com.technoverse.job_assistant.repository.AuthUserRepository;
import com.technoverse.job_assistant.repository.UserProfileRepository;
import lombok.RequiredArgsConstructor;
import org.mindrot.jbcrypt.BCrypt;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final AuthUserRepository userRepository;
    private final UserProfileRepository profileRepository;

    public AuthUser registerUser(String email, String password, String firstName, String lastName) {
        if (userRepository.findByEmail(email).isPresent()) {
            throw new RuntimeException("Email is already in use.");
        }

        AuthUser user = new AuthUser();
        user.setEmail(email);
        user.setPasswordHash(BCrypt.hashpw(password, BCrypt.gensalt()));
        user.setCreatedAt(LocalDateTime.now());

        AuthUser savedUser = userRepository.save(user);

        // Initialize empty profile with firstName and lastName
        UserProfile profile = new UserProfile();
        profile.setUserId(savedUser.getId());
        profile.setEmail(savedUser.getEmail());
        profile.setFirstName(firstName);
        profile.setLastName(lastName);
        profileRepository.save(profile);

        return savedUser;
    }

    public AuthUser authenticateUser(String email, String password) {
        Optional<AuthUser> optionalUser = userRepository.findByEmail(email);

        if (optionalUser.isPresent()) {
            AuthUser user = optionalUser.get();
            if (BCrypt.checkpw(password, user.getPasswordHash())) {
                return user;
            }
        }
        
        throw new RuntimeException("Invalid email or password.");
    }
}
