package com.technoverse.job_assistant.controller;

import com.technoverse.job_assistant.model.UserProfile;
import com.technoverse.job_assistant.service.DecisionEngineService;
import com.technoverse.job_assistant.service.ResumeService;
import com.technoverse.job_assistant.service.ScraperService;
import com.technoverse.job_assistant.service.UserProfileService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/profile")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class UserProfileController {

    private final UserProfileService profileService;
    private final DecisionEngineService decisionEngine;
    private final ResumeService resumeService;
    private final ScraperService scraperService;

    // 1. Profile Save or Update
    @PostMapping("/save")
    public ResponseEntity<UserProfile> saveProfile(@RequestBody UserProfile profile) {
        UserProfile savedProfile = profileService.saveOrUpdateProfile(profile);
        return ResponseEntity.ok(savedProfile);
    }

    // 2. Profile Fetch by userId
    @GetMapping("/{userId}")
    public ResponseEntity<UserProfile> getProfile(@PathVariable String userId) {
        return profileService.getProfileByUserId(userId)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // 3. AI Job Match Analysis (manual text input)
    @PostMapping("/analyze-match")
    public ResponseEntity<String> analyzeMatch(@RequestParam String userId, @RequestBody String jobDescription) {
        UserProfile profile = profileService.getProfileByUserId(userId)
                .orElseThrow(() -> new RuntimeException("User profile not found for ID: " + userId));

        String analysis = decisionEngine.analyzeJobMatch(profile, jobDescription);
        return ResponseEntity.ok(analysis);
    }

    // 4. Resume Builder Agent (AI Resume Generation)
    @GetMapping("/generate-resume/{userId}")
    public ResponseEntity<String> generateResume(@PathVariable String userId) {
        UserProfile profile = profileService.getProfileByUserId(userId)
                .orElseThrow(() -> new RuntimeException("User profile not found for ID: " + userId));

        String optimizedResume = resumeService.generateOptimizedResume(profile);
        return ResponseEntity.ok(optimizedResume);
    }

    // 5. Analyze Job using a Link (Flask Scraper integration)
    @PostMapping("/analyze-link")
    public ResponseEntity<?> analyzeWithLink(@RequestParam String userId, @RequestParam String url) {
        // Step 1: Fetch job description from Flask scraper
        String jobText = scraperService.scrapeJobDescription(url);

        if (jobText == null || jobText.isEmpty()) {
            return ResponseEntity.status(500)
                    .body("Error: Flask scraper failed to fetch job description. Ensure Flask is running on port 5000.");
        }

        // Step 2: Fetch user profile from DB
        UserProfile profile = profileService.getProfileByUserId(userId)
                .orElseThrow(() -> new RuntimeException("User profile not found for ID: " + userId));

        // Step 3: Run AI match analysis
        String analysis = decisionEngine.analyzeJobMatch(profile, jobText);

        return ResponseEntity.ok(analysis);
    }
}