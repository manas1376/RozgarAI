package com.technoverse.job_assistant.service;

import com.technoverse.job_assistant.model.UserProfile;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class ResumeService {

    private final GeminiService geminiService;

    public String generateOptimizedResume(UserProfile profile) {
        String prompt = "Based on this user profile, generate a professional, ATS-optimized resume in Markdown format. " +
                        "Use clear headings for Experience, Skills, and Projects.\n\n" +
                        "PROFILE DATA: " + profile.toString();
        return geminiService.getAiAnalysis(prompt);
    }
}
