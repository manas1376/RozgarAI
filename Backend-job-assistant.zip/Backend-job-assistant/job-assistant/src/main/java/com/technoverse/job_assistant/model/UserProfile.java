package com.technoverse.job_assistant.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;
import java.util.Map;

@Data // Lombok annotation: auto-generates getters, setters, toString, equals, hashCode
@NoArgsConstructor // Lombok annotation: generates a no-args constructor
@AllArgsConstructor // Lombok annotation: generates a constructor with all fields
@Document(collection = "user_profiles") // Tells Spring this class represents a MongoDB document in 'user_profiles' collection
public class UserProfile {

    @Id // Marks this field as the primary key (_id in MongoDB)
    private String id; 

    private String userId; // Link to the Auth User (JWT se aayega baad mein)
    
    // 1. Personal Info
    private String firstName;
    private String lastName;
    private String email; // Gmail
    private String phoneNumber;
    
    // Location
    private String city;
    private String state;

    // Links
    private Map<String, String> links; // E.g., {"linkedin": "url", "github": "url"}

    // 2. Core Skills
    private List<String> skills; // E.g., ["Java", "Spring Boot", "MongoDB", "AI"]

    // 3. Experience (Nested List)
    private List<Experience> experiences;

    // 4. Projects (Nested List)
    private List<Project> projects;

    // 5. Education (Nested List)
    private List<Education> education;

    // 6. Leadership & Achievements
    private List<String> achievements; // Certificates, Club Roles (Technoverse President)

    // AI Generated Data (Baad mein Gemini se bharenge)
    private Integer atsScore;
    private List<String> improvementSuggestions;
    private String optimizedResumeMarkdown; // Gemini generated resume in markdown format

    // --- Inner Classes for Nested Objects ---

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Experience {
        private String companyName;
        private String role;
        private String startDate; // E.g., "Jan 2023"
        private String endDate;   // E.g., "Present" or "Dec 2023"
        private List<String> responsibilities; // Bullet points
        private String location;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Project {
        private String title;
        private String description;
        private List<String> techStack; // E.g., ["Python", "Gemini API"]
        private String projectLink; // GitHub or Live Link
        private String role;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Education {
        private String institutionName;
        private String degree; // E.g., "B.Tech in CSE"
        private String fieldOfStudy;
        private String startDate;
        private String endDate;
        private Double cgpa; // or Percentage
        private String location;
    }
}