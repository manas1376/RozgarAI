package com.technoverse.job_assistant.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "users")
public class AuthUser {

    @Id
    private String id;

    private String email;
    private String passwordHash;
    private LocalDateTime createdAt;
}
