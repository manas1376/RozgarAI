package com.technoverse.job_assistant.controller;

import com.technoverse.job_assistant.model.JobApplication;
import com.technoverse.job_assistant.service.ApplicationService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/applications")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class ApplicationController {

    private final ApplicationService applicationService;

    @PostMapping("/add")
    public ResponseEntity<JobApplication> addApplication(@RequestBody JobApplication application) {
        return ResponseEntity.ok(applicationService.trackNewApplication(application));
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<JobApplication>> getApplications(@PathVariable String userId) {
        return ResponseEntity.ok(applicationService.getUserApplications(userId));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> removeApplication(@PathVariable String id) {
        applicationService.deleteApplication(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/stats/{userId}")
    public ResponseEntity<Map<String, Long>> getStats(@PathVariable String userId) {
        return ResponseEntity.ok(applicationService.getDashboardStats(userId));
    }
}