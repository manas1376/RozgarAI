package com.technoverse.job_assistant.repository;

import com.technoverse.job_assistant.model.UserProfile;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository // Marks this interface as a Spring-managed Bean for database access
public interface UserProfileRepository extends MongoRepository<UserProfile, String> {
    
    // Custom query method: Find a profile by userId
    Optional<UserProfile> findByUserId(String userId);
}