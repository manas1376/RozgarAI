package com.technoverse.job_assistant.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import java.util.HashMap;
import java.util.Map;

@Service
public class ScraperService {

    @Value("${scraper.api.url}")
    private String scraperUrl;

    private final RestTemplate restTemplate = new RestTemplate();

    public String scrapeJobDescription(String jobUrl) {
        try {
            // Flask ko URL bhejne ke liye Map taiyar karna
            Map<String, String> requestBody = new HashMap<>();
            requestBody.put("url", jobUrl);

            // Flask API ko call karna
            Map<String, Object> response = restTemplate.postForObject(scraperUrl, requestBody, Map.class);

            if (response != null && response.containsKey("jobDescription")) {
                return (String) response.get("jobDescription");
            }
        } catch (Exception e) {
            System.err.println("Flask connect nahi ho paya: " + e.getMessage());
        }
        return null;
    }
}
