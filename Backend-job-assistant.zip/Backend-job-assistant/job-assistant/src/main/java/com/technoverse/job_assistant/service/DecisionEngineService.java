package com.technoverse.job_assistant.service;

import com.technoverse.job_assistant.model.UserProfile;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class DecisionEngineService {

    private final GeminiService geminiService;

    public String analyzeJobMatch(UserProfile profile, String jobDescription) {
        String prompt = String.format(
            "Compare this User Profile with the Job Description. Provide analysis in EXACTLY this JSON format: " +
            "{ \"decision\": \"Apply\" | \"Maybe\" | \"Avoid\", \"matchScore\": 85, \"reason\": \"Short reason why\" }\n\n" +
            "USER PROFILE:\n%s\n\nJOB DESCRIPTION:\n%s",
            profile.toString(), jobDescription
        );
        return geminiService.getAiAnalysis(prompt);
    }
}