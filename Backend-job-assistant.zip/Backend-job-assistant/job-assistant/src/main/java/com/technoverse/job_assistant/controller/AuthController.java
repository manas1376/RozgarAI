package com.technoverse.job_assistant.controller;

import com.technoverse.job_assistant.model.AuthUser;
import com.technoverse.job_assistant.service.AuthService;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/auth")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class AuthController {

    private final AuthService authService;

    @PostMapping("/signup")
    public ResponseEntity<?> signup(@RequestBody SignupRequest request) {
        try {
            AuthUser user = authService.registerUser(
                    request.getEmail(), 
                    request.getPassword(), 
                    request.getFirstName(), 
                    request.getLastName());
            return ResponseEntity.ok(new AuthResponse(user.getId(), user.getEmail(), "Signup successful"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(new ErrorResponse(e.getMessage()));
        }
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest request) {
        try {
            AuthUser user = authService.authenticateUser(request.getEmail(), request.getPassword());
            return ResponseEntity.ok(new AuthResponse(user.getId(), user.getEmail(), "Login successful"));
        } catch (Exception e) {
            return ResponseEntity.status(401).body(new ErrorResponse(e.getMessage()));
        }
    }

    @Data
    public static class SignupRequest {
        private String email;
        private String password;
        private String firstName;
        private String lastName;
    }

    @Data
    public static class LoginRequest {
        private String email;
        private String password;
    }

    @Data
    public static class AuthResponse {
        private final String userId;
        private final String email;
        private final String message;
    }

    @Data
    public static class ErrorResponse {
        private final String message;
    }
}
