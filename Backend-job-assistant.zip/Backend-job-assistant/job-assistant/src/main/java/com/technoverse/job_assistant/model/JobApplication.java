package com.technoverse.job_assistant.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "applications")
public class JobApplication {
    @Id
    private String id;
    private String userId;
    private String jobTitle;
    private String company;
    private String status; // Pending, Applied, Interview, Response, Rejected
    private LocalDate appliedDate;
    private String notes;
}
