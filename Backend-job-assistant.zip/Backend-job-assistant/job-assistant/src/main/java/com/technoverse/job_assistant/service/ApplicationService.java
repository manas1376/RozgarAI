package com.technoverse.job_assistant.service;

import com.technoverse.job_assistant.model.JobApplication;
import com.technoverse.job_assistant.repository.ApplicationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ApplicationService {
    private final ApplicationRepository applicationRepository;

    public JobApplication trackNewApplication(JobApplication application) {
        return applicationRepository.save(application);
    }

    public List<JobApplication> getUserApplications(String userId) {
        return applicationRepository.findByUserId(userId);
    }

    public void deleteApplication(String id) {
        applicationRepository.deleteById(id);
    }
    public Map<String, Long> getDashboardStats(String userId) {
    List<JobApplication> apps = applicationRepository.findByUserId(userId);
    
    // Status ke according count karna (e.g., { "Applied": 10, "Interview": 2 })
    return apps.stream()
               .collect(Collectors.groupingBy(JobApplication::getStatus, Collectors.counting()));
}
}
