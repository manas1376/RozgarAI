package com.technoverse.job_assistant.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "jobs")
public class Job {
    @Id
    private String id;
    private String title;
    private String company;
    private String description;
    private String location;
    private String salary;

    // AI Decision Fields
    private String aiDecision; // Apply, Maybe, Avoid
    private Integer matchScore;
    private String aiReason;
}
