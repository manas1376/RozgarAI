package com.technoverse.job_assistant.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.technoverse.job_assistant.model.UserProfile;
import com.technoverse.job_assistant.repository.UserProfileRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class UserProfileService {

    private final UserProfileRepository profileRepository;
    private final GeminiService geminiService;
    private final ObjectMapper objectMapper = new ObjectMapper();

    // Save or Update Profile with real AI analysis
    public UserProfile saveOrUpdateProfile(UserProfile profile) {
        String prompt = "Analyze this user profile JSON and provide: " +
                "1. An ATS Score (0-100). " +
                "2. A list of 3-5 improvement suggestions. " +
                "Return ONLY a valid JSON object with fields 'atsScore' (integer) and 'suggestions' (array of strings). " +
                "No markdown, no explanation, just the JSON object. " +
                "Profile Data: " + profile.toString();

        String aiResponse = geminiService.getAiAnalysis(prompt);

        try {
            // Strip markdown code fences if Gemini wraps it
            String cleaned = aiResponse
                    .replaceAll("(?s)```json\\s*", "")
                    .replaceAll("(?s)```\\s*", "")
                    .trim();

            JsonNode node = objectMapper.readTree(cleaned);

            if (node.has("atsScore")) {
                profile.setAtsScore(node.get("atsScore").asInt());
            }

            if (node.has("suggestions") && node.get("suggestions").isArray()) {
                List<String> suggestions = new ArrayList<>();
                node.get("suggestions").forEach(s -> suggestions.add(s.asText()));
                profile.setImprovementSuggestions(suggestions);
            }
        } catch (Exception e) {
            System.out.println("AI response parsing failed, using fallback values: " + e.getMessage());
            // Fallback — don't crash, just use safe defaults
            if (profile.getAtsScore() == null) {
                profile.setAtsScore(70);
            }
            if (profile.getImprovementSuggestions() == null) {
                profile.setImprovementSuggestions(
                        List.of("Add quantified achievements", "Include relevant keywords", "Improve summary section")
                );
            }
        }

        return profileRepository.save(profile);
    }

    // Fetch profile by userId
    public Optional<UserProfile> getProfileByUserId(String userId) {
        return profileRepository.findByUserId(userId);
    }
}